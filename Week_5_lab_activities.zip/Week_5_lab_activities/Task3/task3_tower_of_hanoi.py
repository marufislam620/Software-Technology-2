move_count = 0


def move_disks(n, from_tower, to_tower, aux_tower):
    global move_count

    if n == 1:
        print(f"Move disk 1 from {from_tower} to {to_tower}")
        move_count += 1
    else:
        move_disks(n - 1, from_tower, aux_tower, to_tower)
        print(f"Move disk {n} from {from_tower} to {to_tower}")
        move_count += 1
        move_disks(n - 1, aux_tower, to_tower, from_tower)


def run_test(n):
    global move_count
    move_count = 0

    print(f"\n=== Tower of Hanoi for n = {n} disks ===")
    print("The moves are:")
    move_disks(n, 'A', 'B', 'C')
    print(f"Number of moves is {move_count}")


# Test for at least two different disk sizes
run_test(3)
run_test(4)
