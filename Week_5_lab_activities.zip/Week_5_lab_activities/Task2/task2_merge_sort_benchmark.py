import random
import timeit


# MERGE SORT

def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        mid = len(array) // 2
        left = merge_sort(array[:mid])
        right = merge_sort(array[mid:])
        return merge(left, right)


def merge(left, right):
    merged = []
    left_pointer = 0
    right_pointer = 0

    while left_pointer < len(left) and right_pointer < len(right):
        if left[left_pointer] < right[right_pointer]:
            merged.append(left[left_pointer])
            left_pointer += 1
        else:
            merged.append(right[right_pointer])
            right_pointer += 1

    merged.extend(left[left_pointer:])
    merged.extend(right[right_pointer:])
    return merged


# INSERTION SORT

def insertion_sort(arr):
    arr = arr[:]  # keep original list unchanged
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current_element
    return arr


# TEST CASES

print("=== CORRECTNESS TESTS ===")
test1 = [2, 6, 9, 5, 3, 4, 5, 6, 6, 7]
test2 = [1]
test3 = [9, 8, 7, 6, 5, 4, 3, 2, 1]

for test in [test1, test2, test3]:
    print("\nOriginal:", test)
    print("Merge sort:", merge_sort(test))
    print("Insertion sort:", insertion_sort(test))


# BENCHMARKING

print("\n=== BENCHMARKING ===")

sizes = [100, 1000, 5000]

for size in sizes:
    data = [random.randint(1, 10000) for _ in range(size)]

    merge_time = timeit.timeit(lambda: merge_sort(data[:]), number=10)
    insertion_time = timeit.timeit(lambda: insertion_sort(data[:]), number=10)

    print(
        f"Size={size:5} | Merge Sort={merge_time:.6f}s | Insertion Sort={insertion_time:.6f}s")

print("\n=== COMMENTS ===")
print("Merge sort performs better for larger data sizes because its time complexity is O(n log n).")
print("Insertion sort is slower for large lists because its time complexity is O(n^2).")
print("For very small lists, insertion sort may appear acceptable, but merge sort scales much better.")
