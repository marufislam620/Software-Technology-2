from tkinter import *
import math


class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 600
        self.height = 600

        self.canvas = Canvas(window, width=self.width,
                             height=self.height, bg="white")
        self.canvas.pack()

        frame = Frame(window)
        frame.pack()

        Label(frame, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")

        size = 300
        h = math.sqrt(3) / 2 * size

        p1 = [150, 350]
        p2 = [450, 350]
        p3 = [300, 350 - h]

        self.draw_koch(int(self.order.get()), p1, p2)
        self.draw_koch(int(self.order.get()), p2, p3)
        self.draw_koch(int(self.order.get()), p3, p1)

    def draw_koch(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            x1, y1 = p1
            x5, y5 = p2

            x2 = x1 + (x5 - x1) / 3
            y2 = y1 + (y5 - y1) / 3

            x4 = x1 + 2 * (x5 - x1) / 3
            y4 = y1 + 2 * (y5 - y1) / 3

            dx = x4 - x2
            dy = y4 - y2

            angle = math.radians(60)
            x3 = x2 + dx * math.cos(angle) - dy * math.sin(angle)
            y3 = y2 + dx * math.sin(angle) + dy * math.cos(angle)

            p2_new = [x2, y2]
            p3_new = [x3, y3]
            p4_new = [x4, y4]

            self.draw_koch(order - 1, p1, p2_new)
            self.draw_koch(order - 1, p2_new, p3_new)
            self.draw_koch(order - 1, p3_new, p4_new)
            self.draw_koch(order - 1, p4_new, p2)


KochSnowflake()
