import timeit


# RECURSIVE VERSIONS


def sum_recursive(n):
    if n == 1:
        return 1
    return n + sum_recursive(n - 1)


def fibonacci_recursive(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2)


def factorial_recursive(n):
    if n == 0:
        return 1
    return n * factorial_recursive(n - 1)


# ITERATIVE VERSIONS


def sum_iterative(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total


def fibonacci_iterative(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


def factorial_iterative(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result


# TEST OUTPUTS


print("=== CORRECTNESS CHECK ===")
print("Sum recursive(5):", sum_recursive(5))
print("Sum iterative(5):", sum_iterative(5))
print()

print("Fibonacci recursive(7):", fibonacci_recursive(7))
print("Fibonacci iterative(7):", fibonacci_iterative(7))
print()

print("Factorial recursive(5):", factorial_recursive(5))
print("Factorial iterative(5):", factorial_iterative(5))
print()


# BENCHMARKING

print("=== TIMING COMPARISON ===")

sum_sizes = [10, 100, 500]
fib_sizes = [5, 10, 20, 30]
fact_sizes = [5, 10, 50, 100]

print("\n--- Sum of natural numbers ---")
for n in sum_sizes:
    rec_time = timeit.timeit(lambda: sum_recursive(n), number=1000)
    itr_time = timeit.timeit(lambda: sum_iterative(n), number=1000)
    print(f"n={n:3} | recursive={rec_time:.6f}s | iterative={itr_time:.6f}s")

print("\n--- Fibonacci ---")
for n in fib_sizes:
    rec_time = timeit.timeit(lambda: fibonacci_recursive(n), number=10)
    itr_time = timeit.timeit(lambda: fibonacci_iterative(n), number=10)
    print(f"n={n:3} | recursive={rec_time:.6f}s | iterative={itr_time:.6f}s")

print("\n--- Factorial ---")
for n in fact_sizes:
    rec_time = timeit.timeit(lambda: factorial_recursive(n), number=1000)
    itr_time = timeit.timeit(lambda: factorial_iterative(n), number=1000)
    print(f"n={n:3} | recursive={rec_time:.6f}s | iterative={itr_time:.6f}s")

print("\n----COMMENTS----")
print("1. Iteration is usually faster for sum and factorial because it avoids recursive function-call overhead.")
print("2. Recursive Fibonacci becomes very slow as n increases because it repeats the same calculations many times.")
print("3. Iterative Fibonacci is much more efficient than naive recursive Fibonacci.")
