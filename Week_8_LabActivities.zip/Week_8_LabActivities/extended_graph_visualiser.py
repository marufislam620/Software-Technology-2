from graph import Graph
import tkinter as tk
import math
import time
import threading


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry("820x900")
        self.graph = graph

        self.canvas = tk.Canvas(self, width=760, height=760, bg="white")
        self.canvas.pack(pady=10)

        self.vertex_positions = {}
        self.node_radius = 25
        self.spacing = 220
        self.center = (380, 320)
        self.vertex_circles = {}
        self.edge_lines = {}

        control_frame = tk.Frame(self)
        control_frame.pack(pady=5)

        btn_bfs = tk.Button(control_frame, text="Run BFS",
                            command=lambda: self.run_traversal("bfs"))
        btn_bfs.pack(side=tk.LEFT, padx=5)

        btn_dfs = tk.Button(control_frame, text="Run DFS",
                            command=lambda: self.run_traversal("dfs"))
        btn_dfs.pack(side=tk.LEFT, padx=5)

        btn_cycle_undirected = tk.Button(
            control_frame, text="Detect Undirected Cycle", command=self.run_cycle_detection)
        btn_cycle_undirected.pack(side=tk.LEFT, padx=5)

        btn_cycle_directed = tk.Button(
            control_frame, text="Detect Directed Cycle", command=self.run_directed_cycle_detection)
        btn_cycle_directed.pack(side=tk.LEFT, padx=5)

        btn_reset = tk.Button(
            control_frame, text="Reset Colors", command=self.reset_colors)
        btn_reset.pack(side=tk.LEFT, padx=5)

        self.info_label = tk.Label(self, text="", font=("Arial", 11))
        self.info_label.pack(pady=5)

        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_circles.clear()
        self.edge_lines.clear()

        vertices = list(self.graph.graph.keys())
        n = len(vertices)

        if n == 0:
            return

        angle_gap = 360 / n
        cx, cy = self.center

        # Draw vertices in circle
        for i, v in enumerate(vertices):
            angle = i * angle_gap
            x = cx + self.spacing * math.cos(math.radians(angle))
            y = cy + self.spacing * math.sin(math.radians(angle))

            self.vertex_positions[v] = (x, y)

            circle_id = self.canvas.create_oval(
                x - self.node_radius, y - self.node_radius,
                x + self.node_radius, y + self.node_radius,
                fill="lightblue", outline="black", width=2
            )
            self.vertex_circles[v] = circle_id

            self.canvas.create_text(
                x, y, text=v, font=("Arial", 16, "bold")
            )

        drawn_edges = set()

        # Draw edges
        for v in vertices:
            x1, y1 = self.vertex_positions[v]

            for nbr in self.graph.graph[v]:
                if not self.graph.directed:
                    if (nbr, v) in drawn_edges:
                        continue

                x2, y2 = self.vertex_positions[nbr]

                dx = x2 - x1
                dy = y2 - y1
                dist = math.sqrt(dx * dx + dy * dy)

                if dist == 0:
                    continue

                offset_x = dx / dist * self.node_radius
                offset_y = dy / dist * self.node_radius

                start_x = x1 + offset_x
                start_y = y1 + offset_y
                end_x = x2 - offset_x
                end_y = y2 - offset_y

                if self.graph.directed:
                    line_id = self.canvas.create_line(
                        start_x, start_y, end_x, end_y,
                        arrow=tk.LAST, width=2
                    )
                else:
                    line_id = self.canvas.create_line(
                        start_x, start_y, end_x, end_y,
                        width=2
                    )

                self.edge_lines[(v, nbr)] = line_id
                drawn_edges.add((v, nbr))

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), "")
                    mid_x = (start_x + end_x) / 2
                    mid_y = (start_y + end_y) / 2 - 15
                    self.canvas.create_text(
                        mid_x, mid_y,
                        text=str(w),
                        fill="red",
                        font=("Arial", 12, "bold")
                    )

    def reset_colors(self):
        for circle_id in self.vertex_circles.values():
            self.canvas.itemconfig(circle_id, fill="lightblue")

        for edge_id in self.edge_lines.values():
            self.canvas.itemconfig(edge_id, fill="black", width=2)

        self.info_label.config(text="Colors reset.")
        self.update()

    def highlight_vertex(self, vertex, color):
        if vertex in self.vertex_circles:
            self.canvas.itemconfig(self.vertex_circles[vertex], fill=color)
            self.update()

    def highlight_edge(self, v1, v2, color):
        line_id = self.edge_lines.get((v1, v2))

        if line_id is None and not self.graph.directed:
            line_id = self.edge_lines.get((v2, v1))

        if line_id:
            self.canvas.itemconfig(line_id, fill=color, width=3)
            self.update()

    def run_traversal(self, method):
        def worker():
            self.reset_colors()
            visited = set()
            order = []

            start_vertex = "A" if "A" in self.graph.graph else next(
                iter(self.graph.graph), None)

            if not start_vertex:
                self.info_label.config(text="Graph is empty.")
                return

            if method == "bfs":
                queue = [start_vertex]
                self.info_label.config(text="Running BFS...")

                while queue:
                    vertex = queue.pop(0)

                    if vertex not in visited:
                        visited.add(vertex)
                        order.append(vertex)
                        self.highlight_vertex(vertex, "orange")
                        self.info_label.config(text=f"BFS visiting: {vertex}")
                        time.sleep(0.6)

                        for nbr in self.graph.graph[vertex]:
                            if nbr not in visited and nbr not in queue:
                                queue.append(nbr)
                                self.highlight_edge(vertex, nbr, "green")
                                time.sleep(0.3)

                self.info_label.config(
                    text="BFS complete: " + " -> ".join(order))

            elif method == "dfs":
                stack = [start_vertex]
                self.info_label.config(text="Running DFS...")

                while stack:
                    vertex = stack.pop()

                    if vertex not in visited:
                        visited.add(vertex)
                        order.append(vertex)
                        self.highlight_vertex(vertex, "purple")
                        self.info_label.config(text=f"DFS visiting: {vertex}")
                        time.sleep(0.6)

                        for nbr in reversed(self.graph.graph[vertex]):
                            if nbr not in visited:
                                stack.append(nbr)
                                self.highlight_edge(vertex, nbr, "blue")
                                time.sleep(0.3)

                self.info_label.config(
                    text="DFS complete: " + " -> ".join(order))

        threading.Thread(target=worker, daemon=True).start()

    def run_cycle_detection(self):
        def worker():
            self.reset_colors()

            if self.graph.directed:
                self.info_label.config(
                    text="This graph is directed. Use an undirected graph for this button.")
                return

            self.info_label.config(
                text="Detecting cycles in undirected graph...")
            visited = set()
            has_cycle = False

            def cycle_dfs(current, parent):
                self.highlight_vertex(current, "yellow")
                visited.add(current)
                time.sleep(0.5)

                for nbr in self.graph.graph[current]:
                    if nbr not in visited:
                        self.highlight_edge(current, nbr, "orange")
                        time.sleep(0.4)
                        if cycle_dfs(nbr, current):
                            self.highlight_vertex(current, "red")
                            return True
                    elif nbr != parent:
                        self.highlight_edge(current, nbr, "red")
                        self.highlight_vertex(current, "red")
                        self.highlight_vertex(nbr, "red")
                        return True

                return False

            for vertex in self.graph.graph:
                if vertex not in visited:
                    if cycle_dfs(vertex, None):
                        has_cycle = True
                        break

            if has_cycle:
                self.info_label.config(
                    text="Cycle detected in the undirected graph!")
            else:
                self.info_label.config(
                    text="No cycles found in the undirected graph.")

        threading.Thread(target=worker, daemon=True).start()

    def run_directed_cycle_detection(self):
        def worker():
            self.reset_colors()

            if not self.graph.directed:
                self.info_label.config(
                    text="This graph is undirected. Use a directed graph for this button.")
                return

            self.info_label.config(
                text="Detecting cycles in directed graph...")
            visited = set()
            rec_stack = set()
            has_cycle = False

            def dfs(vertex):
                visited.add(vertex)
                rec_stack.add(vertex)
                self.highlight_vertex(vertex, "yellow")
                time.sleep(0.5)

                for nbr in self.graph.graph[vertex]:
                    if nbr not in visited:
                        self.highlight_edge(vertex, nbr, "orange")
                        time.sleep(0.4)
                        if dfs(nbr):
                            self.highlight_edge(vertex, nbr, "red")
                            self.highlight_vertex(vertex, "red")
                            return True
                    elif nbr in rec_stack:
                        self.highlight_edge(vertex, nbr, "red")
                        self.highlight_vertex(vertex, "red")
                        self.highlight_vertex(nbr, "red")
                        return True

                rec_stack.remove(vertex)
                return False

            for vertex in self.graph.graph:
                if vertex not in visited:
                    if dfs(vertex):
                        has_cycle = True
                        break

            if has_cycle:
                self.info_label.config(
                    text="Cycle detected in the directed graph!")
            else:
                self.info_label.config(
                    text="No cycles found in the directed graph.")

        threading.Thread(target=worker, daemon=True).start()


if __name__ == "__main__":
    # Change this value to test the graph you want
    test_mode = "undirected"   # change to "directed" for directed cycle test

    if test_mode == "undirected":
        g = Graph(directed=False)

        for v in ["A", "B", "C", "D"]:
            g.add_vertex(v)

        g.add_edge("A", "B")
        g.add_edge("B", "C")
        g.add_edge("C", "A")   # cycle
        g.add_edge("C", "D")

    elif test_mode == "directed":
        g = Graph(directed=True)

        for v in ["A", "B", "C", "D"]:
            g.add_vertex(v)

        g.add_edge("A", "B")
        g.add_edge("B", "C")
        g.add_edge("C", "A")   # directed cycle
        g.add_edge("C", "D")

    app = GraphVisualizer(g)
    app.mainloop()
