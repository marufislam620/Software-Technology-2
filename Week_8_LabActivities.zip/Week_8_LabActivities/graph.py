class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)

            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                self.graph[vertex2].append(vertex1)

                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            edges_to_remove = []

            for v in self.graph:
                for neighbor in self.graph[v]:
                    if neighbor == vertex:
                        edges_to_remove.append((v, neighbor))

            for edge in edges_to_remove:
                self.remove_edge(edge[0], edge[1])

            del self.graph[vertex]
        else:
            print("Vertex not present in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)

            if self.weighted and (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]

            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)

                if self.weighted and (vertex2, vertex1) in self.weights:
                    del self.weights[(vertex2, vertex1)]
        else:
            print("Edge not present in graph.")

    def print_graph(self):
        for vertex in self.graph:
            if len(self.graph[vertex]) == 0:
                print(vertex)
            else:
                if self.directed:
                    if self.weighted:
                        neighbors = []
                        for neighbor in self.graph[vertex]:
                            neighbors.append(
                                f"{neighbor}({self.weights[(vertex, neighbor)]})")
                        print(f"{vertex} --> {' '.join(neighbors)}")
                    else:
                        print(f"{vertex} --> {' '.join(self.graph[vertex])}")
                else:
                    if self.weighted:
                        neighbors = []
                        for neighbor in self.graph[vertex]:
                            neighbors.append(
                                f"{neighbor}({self.weights[(vertex, neighbor)]})")
                        print(f"{vertex} --- {' '.join(neighbors)}")
                    else:
                        print(f"{vertex} --- {' '.join(self.graph[vertex])}")

    def bfs(self, start_vertex):
        visited = []
        queue = []

        visited.append(start_vertex)
        queue.append(start_vertex)

        while queue:
            vertex = queue.pop(0)

            for neighbor in self.graph[vertex]:
                if neighbor not in visited:
                    visited.append(neighbor)
                    queue.append(neighbor)

        return visited

    def dfs(self, start_vertex):
        visited = []
        stack = [start_vertex]

        while stack:
            vertex = stack.pop()

            if vertex not in visited:
                visited.append(vertex)

                for neighbor in reversed(self.graph[vertex]):
                    if neighbor not in visited:
                        stack.append(neighbor)

        return visited

    def cycle_dfs(self, current_vertex, visited, parent_vertex):
        visited.add(current_vertex)

        for neighbor in self.graph[current_vertex]:
            if neighbor not in visited:
                if self.cycle_dfs(neighbor, visited, current_vertex):
                    return True
            elif neighbor != parent_vertex:
                return True

        return False

    def has_undirected_cycle(self):
        visited = set()

        for vertex in self.graph:
            if vertex not in visited:
                if self.cycle_dfs(vertex, visited, None):
                    return True

        return False

    def directed_cycle_dfs(self, vertex, visited, rec_stack):
        visited.add(vertex)
        rec_stack.add(vertex)

        for neighbor in self.graph[vertex]:
            if neighbor not in visited:
                if self.directed_cycle_dfs(neighbor, visited, rec_stack):
                    return True
            elif neighbor in rec_stack:
                return True

        rec_stack.remove(vertex)
        return False

    def has_directed_cycle(self):
        visited = set()
        rec_stack = set()

        for vertex in self.graph:
            if vertex not in visited:
                if self.directed_cycle_dfs(vertex, visited, rec_stack):
                    return True

        return False
