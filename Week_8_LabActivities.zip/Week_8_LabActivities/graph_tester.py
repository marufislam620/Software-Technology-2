from graph import Graph

print("TASK 1: GRAPH BASICS")
print("--------------------")

# Basic undirected graph
g1 = Graph()
g1.add_vertex('A')
g1.add_vertex('B')
g1.add_vertex('C')
g1.add_vertex('D')

print("After adding vertices A, B, C, D:")
g1.print_graph()
print()

g1.add_edge('A', 'B')
g1.add_edge('B', 'C')
g1.add_edge('C', 'D')

print("After adding undirected edges:")
g1.print_graph()
print()

g1.remove_edge('B', 'C')
print("After removing edge B-C:")
g1.print_graph()
print()

g1.remove_vertex('D')
print("After removing vertex D:")
g1.print_graph()
print()

# Directed graph
g2 = Graph(directed=True)
g2.add_vertex('A')
g2.add_vertex('B')
g2.add_vertex('C')
g2.add_vertex('D')

g2.add_edge('A', 'B')
g2.add_edge('B', 'C')
g2.add_edge('C', 'D')

print("Directed graph:")
g2.print_graph()
print()


print("TASK 2: BFS")
print("-----------")

g3 = Graph()
for v in ['A', 'B', 'C', 'D', 'E']:
    g3.add_vertex(v)

g3.add_edge('A', 'B')
g3.add_edge('A', 'C')
g3.add_edge('B', 'D')
g3.add_edge('C', 'E')

print("Graph for BFS:")
g3.print_graph()
print()

visited_bfs = g3.bfs('A')
print("BFS starting from vertex 'A':")
print("Visited vertices in BFS order:", visited_bfs)
print()


print("TASK 3: DFS")
print("-----------")

visited_dfs = g3.dfs('A')
print("DFS starting from vertex 'A':")
print("Visited vertices in DFS order:", visited_dfs)
print()


print("TASK 4: UNDIRECTED CYCLE DETECTION")
print("----------------------------------")

cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)

cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')

print("Cycle graph:")
cycle_graph.print_graph()
print("Does cycle_graph have a cycle?", cycle_graph.has_undirected_cycle())
print()

acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)

acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("Acyclic graph:")
acyclic_graph.print_graph()
print("Does acyclic_graph have a cycle?", acyclic_graph.has_undirected_cycle())
print()


print("TASK 5: WEIGHTED AND DIRECTED GRAPH")
print("-----------------------------------")

wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

print("Weighted Directed Graph:")
wg.print_graph()
print()
