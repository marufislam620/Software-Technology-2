from graph import Graph
import tkinter as tk
import math


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.graph = graph
        self.canvas = tk.Canvas(self, width=400, height=400, bg='white')
        self.canvas.pack()
        self.vertex_positions = {}
        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")

        radius = 30   # bigger nodes
        spacing = 140  # more spacing

        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 200, 200

        self.vertex_positions = {}

        # Draw vertices
        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap

            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))

            self.vertex_positions[v] = (x, y)

            # Draw circle
            self.canvas.create_oval(
                x - radius, y - radius, x + radius, y + radius,
                fill='#87CEEB', outline='black', width=2
            )

            # Draw label (BIGGER + bold)
            self.canvas.create_text(
                x, y,
                text=v,
                font=("Arial", 14, "bold"),
                fill="black"
            )

        # Draw edges
        drawn_edges = set()

        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]

            for nbr in self.graph.graph[v]:

                # avoid duplicate edges in undirected graph
                if not self.graph.directed:
                    if (nbr, v) in drawn_edges:
                        continue

                x2, y2 = self.vertex_positions[nbr]

                # shorten line so it doesn't go through circle
                dx = x2 - x1
                dy = y2 - y1
                dist = math.sqrt(dx*dx + dy*dy)

                if dist == 0:
                    continue

                offset_x = dx / dist * radius
                offset_y = dy / dist * radius

                start_x = x1 + offset_x
                start_y = y1 + offset_y
                end_x = x2 - offset_x
                end_y = y2 - offset_y

                if self.graph.directed:
                    self.canvas.create_line(
                        start_x, start_y, end_x, end_y,
                        arrow=tk.LAST, width=2
                    )
                else:
                    self.canvas.create_line(
                        start_x, start_y, end_x, end_y,
                        width=2
                    )

                drawn_edges.add((v, nbr))

                # draw weight clearly above line
                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')

                    mid_x = (start_x + end_x) / 2
                    mid_y = (start_y + end_y) / 2 - 10  # move slightly up

                    self.canvas.create_text(
                        mid_x, mid_y,
                        text=str(w),
                        fill="red",
                        font=("Arial", 12, "bold")
                    )


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)

    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')

    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'A', 30)

    app = GraphVisualizer(g)
    app.mainloop()
